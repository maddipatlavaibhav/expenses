"""Excel and PDF downloads of the transactions shown in the UI.

Shared by the server (app/main.py) and the phone app (pwa/bridge.py); no web imports.
Takes the transaction dicts the UI already holds (as produced by service.run).
"""
import io
from collections import defaultdict
from datetime import date
from decimal import Decimal
from pathlib import Path
from xml.sax.saxutils import escape

FORMATS = {
    "xlsx": ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ".xlsx"),
    "pdf": ("application/pdf", ".pdf"),
}


class ExportError(ValueError):
    pass


def inr(v: Decimal) -> str:
    """Indian digit grouping without the symbol: 123456.5 -> 1,23,456.50"""
    whole, frac = f"{abs(v):.2f}".split(".")
    if len(whole) > 3:
        head, groups = whole[:-3], []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        whole = ",".join(([head] if head else []) + groups + [whole[-3:]])
    return ("-" if v < 0 else "") + f"{whole}.{frac}"


def _parse(transactions: list[dict]) -> list[dict]:
    rows = []
    for t in transactions:
        amount = Decimal(t["amount"])
        rows.append({
            "date": date.fromisoformat(t["date"]),
            "merchant": t.get("merchant") or "",
            "channel": t.get("channel") or "",
            "out": amount if t["direction"] == "debit" else None,
            "in": amount if t["direction"] == "credit" else None,
            "balance": None if t.get("balance") is None else Decimal(t["balance"]),
            "upi_id": t.get("upi_id") or "",
            "ref_no": t.get("ref_no") or "",
            "narration": t.get("narration") or "",
            "flags": ", ".join(t.get("issues") or []),
        })
    return rows


def _totals(rows):
    money_in = sum((r["in"] for r in rows if r["in"] is not None), Decimal(0))
    money_out = sum((r["out"] for r in rows if r["out"] is not None), Decimal(0))
    return money_in, money_out


def _by_merchant(rows):
    spend = defaultdict(lambda: [0, Decimal(0)])
    for r in rows:
        if r["out"] is not None:
            m = spend[r["merchant"] or "Unknown"]
            m[0] += 1
            m[1] += r["out"]
    return sorted(spend.items(), key=lambda kv: kv[1][1], reverse=True)


def _xlsx(rows, title: str, note: str) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter

    money, bold = "#,##0.00", Font(bold=True)
    head_fill = PatternFill("solid", fgColor="E3EEEA")
    wb = Workbook()

    ws = wb.active
    ws.title = "Transactions"
    ws.append([title])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append([note] if note else [])
    headers = ["Date", "Merchant", "Channel", "Money out", "Money in", "Balance", "UPI ID", "Ref no", "Narration", "Flags"]
    ws.append(headers)
    hdr = ws.max_row
    for c in ws[hdr]:
        c.font, c.fill = bold, head_fill
    for r in rows:
        ws.append([r["date"], r["merchant"], r["channel"], r["out"], r["in"], r["balance"],
                   r["upi_id"], r["ref_no"], r["narration"], r["flags"]])
    last = ws.max_row
    for row in ws.iter_rows(min_row=hdr + 1, max_row=last):
        row[0].number_format = "DD-MMM-YYYY"
        for c in row[3:6]:
            c.number_format = money
    if rows:
        ws.append([])
        ws.append(["Total", None, None, f"=SUM(D{hdr + 1}:D{last})", f"=SUM(E{hdr + 1}:E{last})"])
        for c in ws[ws.max_row]:
            c.font = bold
            c.number_format = money
    ws.freeze_panes = ws.cell(row=hdr + 1, column=1)
    ws.auto_filter.ref = f"A{hdr}:{get_column_letter(len(headers))}{last}"
    for col, width in zip("ABCDEFGHIJ", (13, 28, 10, 13, 13, 14, 26, 18, 60, 18)):
        ws.column_dimensions[col].width = width

    ms = wb.create_sheet("By merchant")
    ms.append(["Merchant", "Payments", "Money out"])
    for c in ms[1]:
        c.font, c.fill = bold, head_fill
    for name, (n, total) in _by_merchant(rows):
        ms.append([name, n, total])
        ms.cell(row=ms.max_row, column=3).number_format = money
    ms.column_dimensions["A"].width, ms.column_dimensions["C"].width = 32, 14
    ms.freeze_panes = "A2"

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _pdf(rows, title: str, note: str) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    # Built-in PDF fonts have no rupee glyph; amounts are plain numbers under "(INR)" headers.
    def text(s):
        return escape(s.replace("₹", "Rs."))

    styles = getSampleStyleSheet()
    small = styles["BodyText"].clone("small", fontSize=7.5, leading=9)
    money_in, money_out = _totals(rows)
    dates = [r["date"] for r in rows]                # rows follow the table's sort, so use min/max
    period = f"{min(dates):%d %b %Y} – {max(dates):%d %b %Y}" if rows else "—"
    summary = (f"{len(rows)} transactions &nbsp;·&nbsp; {period} &nbsp;·&nbsp; Money in {inr(money_in)} "
               f"&nbsp;·&nbsp; Money out {inr(money_out)} &nbsp;·&nbsp; Net {inr(money_in - money_out)} (INR)")

    head = ["Date", "Merchant", "Channel", "Money out (INR)", "Money in (INR)", "Balance (INR)", "Narration"]
    data = [head] + [[
        f"{r['date']:%d %b %Y}", Paragraph(text(r["merchant"] or "—"), small), r["channel"],
        "" if r["out"] is None else inr(r["out"]), "" if r["in"] is None else inr(r["in"]),
        "" if r["balance"] is None else inr(r["balance"]),
        Paragraph(text(r["narration"]) + (f" <font color='#9A6614'>[{text(r['flags'])}]</font>" if r["flags"] else ""), small),
    ] for r in rows]

    page_w = landscape(A4)[0] - 24 * mm
    widths = [58, 110, 46, 68, 68, 72]
    table = Table(data, colWidths=widths + [page_w - sum(widths)], repeatRows=1)
    style = [
        ("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 7.5),
        ("FONT", (0, 1), (-1, -1), "Helvetica", 7.5),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E3EEEA")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ALIGN", (3, 0), (5, -1), "RIGHT"),
        ("LINEBELOW", (0, 0), (-1, -1), 0.25, colors.HexColor("#DDE2DA")),
        ("TEXTCOLOR", (3, 1), (3, -1), colors.HexColor("#A8432F")),
        ("TEXTCOLOR", (4, 1), (4, -1), colors.HexColor("#2F7A4B")),
    ]
    style += [("BACKGROUND", (0, i), (-1, i), colors.HexColor("#F6F7F3")) for i in range(2, len(data), 2)]
    table.setStyle(TableStyle(style))

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.grey)
        canvas.drawRightString(landscape(A4)[0] - 12 * mm, 7 * mm, f"Page {doc.page}")
        canvas.drawString(12 * mm, 7 * mm, text(title))
        canvas.restoreState()

    story = [Paragraph(text(title), styles["Title"]), Paragraph(summary, styles["BodyText"])]
    if note:
        story.append(Paragraph(f"<i>{text(note)}</i>", styles["BodyText"]))
    story += [Spacer(1, 4 * mm), table]
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=12 * mm, rightMargin=12 * mm,
                      topMargin=10 * mm, bottomMargin=12 * mm, title=title).build(
        story, onFirstPage=footer, onLaterPages=footer)
    return buf.getvalue()


def export(fmt: str, filename: str, transactions: list[dict], note: str = "") -> tuple[bytes, str, str]:
    """Returns (file_bytes, download_name, mime_type)."""
    if fmt not in FORMATS:
        raise ExportError(f"Unknown export format '{fmt}'. Use xlsx or pdf.")
    rows = _parse(transactions)
    stem = Path(filename or "statement").stem
    title = f"Transactions – {stem}"
    content = (_xlsx if fmt == "xlsx" else _pdf)(rows, title, note)
    mime, ext = FORMATS[fmt]
    return content, stem + ext, mime
