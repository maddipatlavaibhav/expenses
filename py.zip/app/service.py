"""Import logic shared by the FastAPI server (app/main.py) and the in-browser app (pwa/).

No web framework or network imports here, so this also runs inside Pyodide.
Every call returns (http_status, json_body).
"""
import uuid
from pathlib import Path

from importer import import_statement
from importer.header import FIELD_ORDER, is_complete, signature
from importer.pipeline import MappingError
from importer.profiles import ProfileStore
from importer.readers import PasswordRequired, StatementReadError, read_grid

PREVIEW_ROWS = 40
MAX_UPLOADS = 20
SUPPORTED = {".csv", ".txt", ".tsv", ".xls", ".xlsx", ".xlsm", ".pdf"}

_uploads: dict[str, dict] = {}      # upload_id -> {path, password, name, owned}


def err(status: int, code: str, message: str, **extra) -> tuple[int, dict]:
    return status, {"code": code, "message": message, **extra}


def register(path: Path, name: str, password: str | None, owned: bool = False) -> str:
    """Remember a file for later calls. Owned files are deleted when forgotten."""
    uid = uuid.uuid4().hex[:12]
    _uploads[uid] = {"path": path, "password": password or None, "name": name, "owned": owned}
    while len(_uploads) > MAX_UPLOADS:                 # forget oldest uploads
        old = _uploads.pop(next(iter(_uploads)))
        if old["owned"]:
            Path(old["path"]).unlink(missing_ok=True)
    return uid


def _preview(grid: list[list[str]]) -> list[list[str]]:
    rows = grid[:PREVIEW_ROWS]
    width = max((len(r) for r in rows), default=0)
    return [[c[:70] for c in r] + [""] * (width - len(r)) for r in rows]


def run(uid: str, use_llm: bool, store: ProfileStore, offer_llm: bool = True) -> tuple[int, dict]:
    """offer_llm=False where no local LLM can exist (the phone app), so the hint doesn't suggest one."""
    u = _uploads.get(uid)
    if not u:
        return err(404, "missing", "Upload not found. Please upload the file again.")
    try:
        grid = read_grid(u["path"], u["password"])
    except PasswordRequired:
        msg = "Wrong password for this PDF." if u["password"] else "This PDF is password-protected. Enter its password and import again."
        return err(400, "password", msg)
    except StatementReadError as e:
        return err(400, "unreadable", str(e))
    if not grid:
        return err(400, "unreadable", "No table found in this file.")

    try:
        r = import_statement(u["path"], u["password"], profiles=store, use_llm=use_llm)
    except MappingError:
        hint = "" if use_llm else " (Tip: enable the local LLM, or map them below.)" if offer_llm else " Map them below."
        return err(422, "mapping", "Couldn't recognise the columns in this statement." + hint,
                   upload_id=uid, filename=u["name"], preview=_preview(grid), header_row=None, mapping={})

    tx = r.transactions
    header = grid[r.header_row]
    money_in = sum(t.amount for t in tx if t.direction == "credit")
    money_out = sum(t.amount for t in tx if t.direction == "debit")
    return 200, {
        "upload_id": uid,
        "filename": u["name"],
        "summary": {
            "count": len(tx),
            "period_start": tx[0].date.isoformat() if tx else None,
            "period_end": tx[-1].date.isoformat() if tx else None,
            "money_in": str(money_in), "money_out": str(money_out),
            "balance_check": r.balance_check, "balance_ok": r.balance_check == "passed",
            "order": r.order, "skipped_rows": r.skipped_rows,
            "mapping_source": r.mapping_source, "header_row": r.header_row,
            "flagged": sum(1 for t in tx if t.issues),
        },
        "columns": [{"field": f, "index": r.mapping[f], "header": header[r.mapping[f]] if r.mapping[f] < len(header) else ""}
                    for f in FIELD_ORDER if f in r.mapping],
        "mapping": r.mapping,
        "warnings": r.warnings,
        "preview": _preview(grid),
        "transactions": [{
            "date": t.date.isoformat(), "amount": str(t.amount), "direction": t.direction,
            "balance": None if t.balance is None else str(t.balance), "merchant": t.merchant,
            "channel": t.channel, "upi_id": t.upi_id, "ref_no": t.ref_no,
            "narration": t.raw_narration, "issues": t.issues, "hash": t.hash, "source_row": t.source_row,
        } for t in tx],
    }


def save_mapping(uid: str, header_row: int, mapping: dict[str, int], use_llm: bool,
                 store: ProfileStore, offer_llm: bool = True) -> tuple[int, dict]:
    u = _uploads.get(uid)
    if not u:
        return err(404, "missing", "Upload not found. Please upload the file again.")
    if not is_complete(mapping):
        return err(400, "incomplete", "Pick at least Date, Narration, and either Debit + Credit or Amount.")
    grid = read_grid(u["path"], u["password"])
    if not 0 <= header_row < len(grid):
        return err(400, "bad_row", "Header row is out of range.")
    header = grid[header_row]
    store.save(signature(header), header, mapping, "manual")
    return run(uid, use_llm, store, offer_llm)


def list_profiles(store: ProfileStore) -> tuple[int, list]:
    return 200, [{"signature": sig, **p} for sig, p in store.all().items()]


def delete_profile(sig: str, store: ProfileStore) -> tuple[int, dict]:
    if not store.delete(sig):
        return err(404, "missing", "Layout not found.")
    return 200, {"deleted": sig}
