"""In-browser entry point (runs in Pyodide): the calls app/main.py serves over HTTP, as plain functions.

pwa/local-api.js calls these. Each returns a JSON string of [http_status, body].
"""
import functools
import json
import sys
import types
from pathlib import Path

# pdfplumber imports pypdfium2 (native; only used to render page images) and importer.llm
# imports httpx (the local LLM isn't reachable from a phone). Neither is used here.
for _name in ("pypdfium2", "httpx"):
    sys.modules.setdefault(_name, types.ModuleType(_name))


def enable_pdf():
    """Called by local-api.js once the PDF packages are loaded."""
    import crypto_shim
    crypto_shim.install()


from app import export, service  # noqa: E402
from importer.profiles import ProfileStore  # noqa: E402

SAMPLES = Path(__file__).parent / "samples"
PROFILES = Path("/data/profiles.json")      # local-api.js mirrors this file to localStorage


def _store() -> ProfileStore:
    return ProfileStore(PROFILES)


def _api(fn):
    @functools.wraps(fn)
    def wrapper(*args):
        try:
            status, body = fn(*args)
        except Exception as e:
            status, body = service.err(500, "error", f"Something went wrong: {e}")
        return json.dumps([status, body])
    return wrapper


@_api
def list_samples():
    return 200, sorted(p.name for p in SAMPLES.iterdir() if p.suffix in {".csv", ".xlsx", ".xls", ".pdf"})


@_api
def import_file(path: str, name: str, password: str):
    p = Path(path)
    if p.suffix.lower() not in service.SUPPORTED:
        p.unlink(missing_ok=True)
        return service.err(400, "unsupported", f"Unsupported file type '{p.suffix or '?'}'. Use CSV, XLS, XLSX or PDF.")
    return service.run(service.register(p, name, password, owned=True), False, _store(), offer_llm=False)


@_api
def import_sample(name: str):
    path = SAMPLES / Path(name).name
    if not path.exists():
        return service.err(404, "missing", f"Sample {name} not found.")
    return service.run(service.register(path, path.name, None), False, _store(), offer_llm=False)


@_api
def save_mapping(body_json: str):
    b = json.loads(body_json)
    mapping = {k: int(v) for k, v in b["mapping"].items()}
    return service.save_mapping(b["upload_id"], int(b["header_row"]), mapping, False, _store(), offer_llm=False)


def export_file(body_json: str) -> bytes:
    """Excel/PDF bytes for local-api.js to download. Raises export.ExportError on a bad format."""
    b = json.loads(body_json)
    content, _name, _mime = export.export(b["format"], b.get("filename", ""), b["transactions"], b.get("note", ""))
    return content


@_api
def list_profiles():
    return service.list_profiles(_store())


@_api
def delete_profile(sig: str):
    return service.delete_profile(sig, _store())
