"""Stand-in for the few `cryptography` calls pdfminer makes (AES-CBC for encrypted PDFs), backed by pycryptodome.

Pyodide's own `cryptography` build aborts the runtime on import, so the phone app registers this
under the `cryptography` name instead.
"""
import sys
import types

from Crypto.Cipher import AES as _AES


class _Context:
    """Like cryptography's CipherContext: update() may get partial blocks, which are held back."""

    def __init__(self, key: bytes, iv: bytes, decrypt: bool):
        cipher = _AES.new(key, _AES.MODE_CBC, iv)
        self._op = cipher.decrypt if decrypt else cipher.encrypt
        self._pending = b""

    def update(self, data) -> bytes:
        data = self._pending + bytes(data)
        n = len(data) - len(data) % 16
        self._pending = data[n:]
        return self._op(data[:n]) if n else b""

    def finalize(self) -> bytes:
        return b""


class AES:
    def __init__(self, key):
        self.key = bytes(key)


class CBC:
    def __init__(self, initialization_vector):
        self.iv = bytes(initialization_vector)


class Cipher:
    def __init__(self, algorithm: AES, mode: CBC, backend=None):
        self._key, self._iv = algorithm.key, mode.iv

    def decryptor(self) -> _Context:
        return _Context(self._key, self._iv, decrypt=True)

    def encryptor(self) -> _Context:
        return _Context(self._key, self._iv, decrypt=False)


def install():
    def module(name, **attrs):
        m = types.ModuleType(name)
        m.__dict__.update(attrs)
        m.__path__ = []                                  # importable as a package
        sys.modules[name] = m
        return m

    algorithms = module("cryptography.hazmat.primitives.ciphers.algorithms", AES=AES)
    modes = module("cryptography.hazmat.primitives.ciphers.modes", CBC=CBC)
    module("cryptography.hazmat.primitives.ciphers", Cipher=Cipher, algorithms=algorithms, modes=modes)
    module("cryptography.hazmat.primitives")
    module("cryptography.hazmat.backends", default_backend=lambda: None)
    module("cryptography.hazmat")
    module("cryptography")
