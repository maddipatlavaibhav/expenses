"""CLI: python -m importer statement.xlsx [--password X] [--no-llm] [--json out.json]"""
import argparse
import json

from . import import_statement
from .profiles import ProfileStore


def main():
    p = argparse.ArgumentParser(description="Import a bank statement")
    p.add_argument("path")
    p.add_argument("--password")
    p.add_argument("--account", default="default")
    p.add_argument("--profiles", help="profiles.json path")
    p.add_argument("--no-llm", action="store_true")
    p.add_argument("--json", help="write transactions to this JSON file")
    p.add_argument("--show", type=int, default=15, help="rows to print")
    a = p.parse_args()

    r = import_statement(a.path, a.password, a.account, ProfileStore(a.profiles), not a.no_llm)
    tx = r.transactions
    out = sum(t.amount for t in tx if t.direction == "debit")
    inc = sum(t.amount for t in tx if t.direction == "credit")
    print(f"Header row     : {r.header_row}  (mapping via {r.mapping_source})")
    print(f"Columns        : {r.mapping}")
    print(f"Transactions   : {len(tx)}   skipped rows: {r.skipped_rows}   order: {r.order}")
    if tx:
        print(f"Period         : {tx[0].date} → {tx[-1].date}")
    print(f"Money in / out : ₹{inc:,.2f} / ₹{out:,.2f}")
    print(f"Balance check  : {r.balance_check}")
    for w in r.warnings:
        print(f"⚠ {w}")
    print()
    for t in tx[: a.show]:
        sign = "+" if t.direction == "credit" else "-"
        flag = "  ⚠ " + ", ".join(t.issues) if t.issues else ""
        print(f"{t.date}  {sign}{t.amount:>11,.2f}  {t.channel or '':<5} {(t.merchant or '')[:28]:<28} {t.raw_narration[:45]}{flag}")
    if len(tx) > a.show:
        print(f"... {len(tx) - a.show} more")

    if a.json:
        rows = [{**t.__dict__, "date": t.date.isoformat(), "amount": str(t.amount),
                 "balance": None if t.balance is None else str(t.balance)} for t in tx]
        with open(a.json, "w") as f:
            json.dump(rows, f, indent=2, ensure_ascii=False)
        print(f"\nSaved {len(rows)} transactions to {a.json}")


if __name__ == "__main__":
    main()
