"""Parse messy Indian-bank amounts and dates."""
import re
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

_DATE_FORMATS = [
    "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d/%m/%y", "%d-%m-%y", "%d.%m.%y",
    "%d-%b-%Y", "%d-%b-%y", "%d %b %Y", "%d %b %y", "%d/%b/%Y", "%d/%b/%y",
    "%d-%B-%Y", "%d %B %Y", "%Y-%m-%d", "%b %d, %Y",
]
_DRCR = re.compile(r"^\s*(dr|cr)\.?\s*|\s*(dr|cr)\.?\s*$", re.I)


def parse_date(s: str) -> date | None:
    s = (s or "").strip()
    if not s:
        return None
    if re.match(r"^\d{4}-\d{2}-\d{2}[ T]", s):   # ISO datetime from Excel
        s = s[:10]
    for fmt in _DATE_FORMATS:                     # day-first always (India)
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def parse_amount(s: str) -> tuple[Decimal | None, str | None]:
    """Returns (signed amount, 'dr'/'cr' hint if the text carried one)."""
    s = (s or "").strip()
    if not s:
        return None, None
    hint = None
    m = _DRCR.search(s)
    if m:
        hint = (m.group(1) or m.group(2)).lower()
        s = _DRCR.sub("", s)
    neg = s.startswith("-") or (s.startswith("(") and s.endswith(")"))
    s = re.sub(r"(?i)₹|inr|rs\.?|[,\s()+-]", "", s)
    if not s or not re.fullmatch(r"\d*\.?\d+", s):
        return None, hint
    try:
        val = Decimal(s).quantize(Decimal("0.01"))
    except InvalidOperation:
        return None, hint
    return (-val if neg else val), hint
