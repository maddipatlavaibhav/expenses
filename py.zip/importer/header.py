"""Find the header row and map columns to standard fields using synonyms."""
import hashlib
import re

# Order matters: earlier synonyms win (e.g. transaction date beats value date).
SYNONYMS: dict[str, list[str]] = {
    "date": ["transaction date", "txn date", "tran date", "trans date", "date",
             "posting date", "post date", "value date"],
    "narration": ["narration", "transaction remarks", "particulars", "description",
                  "remarks", "transaction details", "details"],
    "debit": ["withdrawal amount", "withdrawal amt", "withdrawals", "withdrawal",
              "debit amount", "debit amt", "debit", "dr amount", "dr"],
    "credit": ["deposit amount", "deposit amt", "deposits", "deposit",
               "credit amount", "credit amt", "credit", "cr amount", "cr"],
    "amount": ["transaction amount", "txn amount", "amount"],
    "dr_cr": ["dr/cr", "cr/dr", "debit/credit", "transaction type", "txn type", "type"],
    "balance": ["closing balance", "available balance", "running balance",
                "balance amount", "balance"],
    "ref": ["chq/ref no", "ref no/cheque no", "cheque number", "cheque no", "chq no",
            "reference no", "ref no", "utr"],
}
# Map debit/credit before amount so 'withdrawal amount' isn't grabbed as 'amount'.
FIELD_ORDER = ["date", "narration", "debit", "credit", "balance", "ref", "dr_cr", "amount"]


def norm(cell: str) -> str:
    s = (cell or "").lower()
    s = re.sub(r"\(.*?\)", " ", s)          # drop "(INR)" etc.
    s = re.sub(r"[._#:]", " ", s)
    s = re.sub(r"\s*/\s*", "/", s)
    return " ".join(s.split())


def map_columns(header: list[str]) -> dict[str, int]:
    cells = [norm(c) for c in header]
    used: set[int] = set()
    mapping: dict[str, int] = {}

    def find(field: str, contains: bool) -> int | None:
        for syn in SYNONYMS[field]:
            for i, c in enumerate(cells):
                if i in used or not c:
                    continue
                if c == syn or (contains and len(syn) >= 4 and re.search(rf"\b{re.escape(syn)}\b", c)):
                    return i
        return None

    for field in FIELD_ORDER:
        if field == "amount" and ("debit" in mapping or "credit" in mapping):
            continue
        idx = find(field, contains=False)
        if idx is None:
            idx = find(field, contains=True)
        if idx is not None:
            mapping[field] = idx
            used.add(idx)
    return mapping


def is_complete(m: dict[str, int]) -> bool:
    has_amounts = ("debit" in m and "credit" in m) or "amount" in m
    return "date" in m and "narration" in m and has_amounts


def detect_header(grid: list[list[str]], scan_rows: int = 60) -> tuple[int, dict[str, int]] | None:
    for i, row in enumerate(grid[:scan_rows]):
        if sum(1 for c in row if c) < 3:
            continue
        m = map_columns(row)
        if is_complete(m):
            return i, m
    return None


def signature(header: list[str]) -> str:
    key = "|".join(norm(c) for c in header if norm(c))
    return hashlib.sha1(key.encode()).hexdigest()[:16]
