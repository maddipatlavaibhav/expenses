"""Fallback column mapping via any OpenAI-compatible endpoint (Ollama by default)."""
import json
import os

import httpx

BASE_URL = os.getenv("LLM_BASE_URL", "http://localhost:11434/v1")
MODEL = os.getenv("LLM_MODEL", "qwen2.5:7b-instruct")
FIELDS = ["date", "narration", "debit", "credit", "amount", "dr_cr", "balance", "ref"]

_SYSTEM = "You identify the structure of bank statement tables. Reply with JSON only."
_PROMPT = """Below are the first rows of a bank statement, one per line as
`row_index: [cell0 | cell1 | ...]`.

{rows}

Find the header row and map columns to these fields (0-based column index):
- date: transaction date (prefer it over value date)
- narration: description / remarks
- debit and credit: separate withdrawal and deposit columns, OR
- amount: a single amount column, with dr_cr: the column saying debit/credit (if any)
- balance: running balance (optional)
- ref: cheque / reference number (optional)
Omit fields that don't exist.

Reply exactly as: {{"header_row": <int>, "mapping": {{"<field>": <int>, ...}}}}"""


def suggest_mapping(grid: list[list[str]], max_rows: int = 30, timeout: float = 60) -> tuple[int, dict[str, int]] | None:
    rows = [(i, r) for i, r in enumerate(grid[:max_rows]) if any(r)]
    text = "\n".join(f"{i}: [{' | '.join(c[:40] for c in r)}]" for i, r in rows)
    try:
        resp = httpx.post(
            f"{BASE_URL}/chat/completions",
            json={
                "model": MODEL,
                "temperature": 0,
                "response_format": {"type": "json_object"},
                "messages": [
                    {"role": "system", "content": _SYSTEM},
                    {"role": "user", "content": _PROMPT.format(rows=text)},
                ],
            },
            timeout=timeout,
        )
        resp.raise_for_status()
        data = json.loads(resp.json()["choices"][0]["message"]["content"])
        hdr = int(data["header_row"])
        width = len(grid[hdr])
        mapping = {f: int(v) for f, v in data["mapping"].items()
                   if f in FIELDS and v is not None and 0 <= int(v) < width}
        return hdr, mapping
    except Exception:
        return None
