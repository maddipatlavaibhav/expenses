from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Optional


@dataclass
class Transaction:
    date: date
    amount: Decimal              # always positive
    direction: str               # "debit" | "credit"
    raw_narration: str
    balance: Optional[Decimal] = None
    ref_no: Optional[str] = None
    channel: Optional[str] = None     # UPI / NEFT / IMPS / ACH / ATM ...
    merchant: Optional[str] = None
    upi_id: Optional[str] = None
    hash: str = ""
    source_row: int = -1              # row index in the original file
    issues: list[str] = field(default_factory=list)

    @property
    def signed(self) -> Decimal:
        return self.amount if self.direction == "credit" else -self.amount
