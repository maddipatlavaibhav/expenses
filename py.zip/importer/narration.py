"""Bank-agnostic narration parsing: channel, UPI id, ref no, merchant."""
import re

_VPA = re.compile(r"[\w.\-]{2,}@[a-zA-Z][a-zA-Z0-9]{1,}")
_VPA_NO_HYPHEN = re.compile(r"[\w.]{2,}@[a-zA-Z][a-zA-Z0-9]{1,}")
_UPI_REF = re.compile(r"(?<!\d)\d{12}(?!\d)")
_IFSC = re.compile(r"^[A-Z]{4}0[A-Z0-9]{6}$")
_CHANNELS = ["UPI", "NEFT", "IMPS", "RTGS", "NACH", "ACH", "ATM", "POS", "ECS"]
_NOISE_TOKENS = {
    "UPI", "NEFT", "IMPS", "RTGS", "ACH", "NACH", "ATM", "POS", "ECS", "DR", "CR",
    "P2A", "P2M", "MMT", "INF", "INFT", "BIL", "ONL", "NA", "N/A", "REV", "UPIINTENT", "NWD", "D",
}
_NOISE_PHRASES = re.compile(
    r"^(payment from ph(one)?|sent using .*|upi intent|pay to|paid via .*|no remarks?|"
    r"collect request|payment|transfer|upi payment)$", re.I)


def _is_noise(tok: str) -> bool:
    t = tok.strip()
    if len(t) < 3 or all(w in _NOISE_TOKENS for w in t.upper().split()):
        return True     # "UPI", "NEFT CR", "ACH D" ...
    if _VPA.fullmatch(t) or _IFSC.match(t.upper()) or _NOISE_PHRASES.match(t):
        return True
    if not re.search(r"[A-Za-z]", t):                   # pure numbers / refs
        return True
    if " " not in t and len(re.findall(r"\d", t)) >= 4:  # alnum refs like CITIN26123456
        return True
    if re.fullmatch(r"[A-Z]{4}", t):                     # bank codes: YESB, ICIC...
        return True
    return False


def _pretty(tok: str) -> str:
    tok = " ".join(tok.split())
    return tok.title() if tok.isupper() or tok.islower() else tok


def parse_narration(text: str) -> dict:
    text = text or ""
    up = text.upper()
    channel = next((c for c in _CHANNELS if re.search(rf"(^|[^A-Z]){c}([^A-Z]|$)", up)), None)
    if channel is None and re.search(r"(^|[^A-Z])NWD([^A-Z]|$)", up):
        channel = "ATM"

    # In '-'-delimited narrations (HDFC style) a hyphen can't belong to the VPA reliably
    vpa_re = _VPA_NO_HYPHEN if re.match(r"^\s*[A-Z]{2,5}\s*-", up) else _VPA
    vpa_m = vpa_re.search(text)
    upi_id = vpa_m.group(0).lower() if vpa_m else None
    ref_m = _UPI_REF.search(text)
    ref_no = ref_m.group(0) if ref_m else None

    if channel == "ATM":
        merchant = "ATM cash withdrawal"
    else:
        no_vpa = vpa_re.sub("/", text)           # VPAs can contain '-', remove before splitting
        tokens = [t.strip() for t in re.split(r"[/|\\:\-]", no_vpa) if t.strip()]
        candidates = [t for t in tokens if not _is_noise(t)]
        if candidates:
            merchant = _pretty(candidates[0])
        elif upi_id:
            merchant = upi_id.split("@")[0]
        else:
            merchant = _pretty(text[:40]) if text else None

    return {"channel": channel, "upi_id": upi_id, "ref_no": ref_no, "merchant": merchant}
