"""File -> grid -> header/mapping -> clean rows -> Transactions."""
import hashlib
from collections import Counter
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path

from . import llm
from .clean import parse_amount, parse_date
from .header import detect_header, is_complete, map_columns, norm, signature
from .models import Transaction
from .narration import parse_narration
from .profiles import ProfileStore
from .readers import read_grid


class MappingError(Exception):
    pass


@dataclass
class ImportResult:
    transactions: list[Transaction]
    header_row: int
    mapping: dict[str, int]
    mapping_source: str              # profile | synonyms | llm
    order: str                       # oldest_first | newest_first | unknown
    balance_check: str
    skipped_rows: int
    warnings: list[str] = field(default_factory=list)


def _get(row: list[str], m: dict[str, int], f: str) -> str:
    i = m.get(f)
    return row[i].strip() if i is not None and i < len(row) and row[i] else ""


def _direction(dr_cr: str, hint: str | None, signed: Decimal) -> tuple[str, bool]:
    t = dr_cr.strip().lower()
    if t in ("c", "cr", "credit") or t.startswith(("cr", "dep")):
        return "credit", False
    if t in ("d", "dr", "debit") or t.startswith(("dr", "deb", "with")):
        return "debit", False
    if hint:
        return ("credit" if hint == "cr" else "debit"), False
    if signed < 0:
        return "debit", False
    return "debit", True   # positive with no type info: guess and flag


def _build(row: list[str], m: dict[str, int], idx: int) -> Transaction | None:
    d = parse_date(_get(row, m, "date"))
    if not d:
        return None
    issues = []
    if "debit" in m or "credit" in m:
        dr, _ = parse_amount(_get(row, m, "debit"))
        cr, _ = parse_amount(_get(row, m, "credit"))
        dr, cr = abs(dr or 0), abs(cr or 0)
        if not dr and not cr:
            return None                          # e.g. opening-balance line
        if dr and cr:
            issues.append("both debit and credit set; using net")
        net = cr - dr
        amount, direction = abs(net), ("credit" if net > 0 else "debit")
    else:
        a, hint = parse_amount(_get(row, m, "amount"))
        if not a:
            return None
        direction, guessed = _direction(_get(row, m, "dr_cr"), hint, a)
        if guessed:
            issues.append("direction guessed")
        amount = abs(a)

    bal, bhint = parse_amount(_get(row, m, "balance"))
    if bal is not None and bhint == "dr":
        bal = -abs(bal)

    narration = _get(row, m, "narration")
    info = parse_narration(narration)
    return Transaction(
        date=d, amount=amount, direction=direction, raw_narration=narration,
        balance=bal, ref_no=_get(row, m, "ref") or info["ref_no"],
        channel=info["channel"], merchant=info["merchant"], upi_id=info["upi_id"],
        source_row=idx, issues=issues,
    )


def _check_balances(txns: list[Transaction]) -> tuple[str, str]:
    b = [t for t in txns if t.balance is not None]
    if len(b) < 2:
        return "unknown", "skipped (no balance column)"
    fwd = [i for i in range(1, len(b)) if b[i].balance != b[i - 1].balance + b[i].signed]
    rev = [i for i in range(1, len(b)) if b[i - 1].balance != b[i].balance + b[i - 1].signed]
    if len(fwd) <= len(rev):
        order, bad = "oldest_first", [b[i] for i in fwd]
    else:
        order, bad = "newest_first", [b[i - 1] for i in rev]
    for t in bad:
        t.issues.append("balance mismatch")
    status = "passed" if not bad else f"{len(bad)} of {len(b) - 1} rows mismatched"
    return order, status


def _assign_hashes(txns: list[Transaction], account_id: str):
    seen: Counter = Counter()
    for t in txns:
        key = "|".join([account_id, t.date.isoformat(), str(t.amount), t.direction,
                        " ".join(t.raw_narration.lower().split()),
                        str(t.balance) if t.balance is not None else ""])
        seen[key] += 1                     # genuine identical txns stay distinct
        t.hash = hashlib.sha256(f"{key}|{seen[key]}".encode()).hexdigest()[:24]


def resolve_mapping(grid, profiles: ProfileStore, use_llm: bool):
    found = detect_header(grid)
    if found:
        hdr, synonym_map = found
        sig = signature(grid[hdr])
        prof = profiles.get(sig)
        if prof:
            return hdr, {k: int(v) for k, v in prof["mapping"].items()}, "profile"
        profiles.save(sig, grid[hdr], synonym_map, "synonyms")
        return hdr, synonym_map, "synonyms"

    # Header not recognised: check saved profiles against any early row
    for i, row in enumerate(grid[:60]):
        prof = profiles.get(signature(row))
        if prof and any(row):
            return i, {k: int(v) for k, v in prof["mapping"].items()}, "profile"

    if use_llm:
        res = llm.suggest_mapping(grid)
        if res and is_complete(res[1]):
            hdr, m = res
            profiles.save(signature(grid[hdr]), grid[hdr], m, "llm")
            return hdr, m, "llm"

    raise MappingError("Couldn't identify the statement columns. Map them manually "
                       "and save a profile (see ProfileStore.save).")


def import_statement(path: str | Path, password: str | None = None, account_id: str = "default",
                     profiles: ProfileStore | None = None, use_llm: bool = True) -> ImportResult:
    grid = read_grid(path, password)
    profiles = profiles or ProfileStore()
    hdr, m, source = resolve_mapping(grid, profiles, use_llm)
    header_norm = [norm(c) for c in grid[hdr]]

    txns: list[Transaction] = []
    skipped, last_was_txn = 0, False
    for idx in range(hdr + 1, len(grid)):
        row = grid[idx]
        if not any(row):
            last_was_txn = False
            continue
        if [norm(c) for c in row] == header_norm:     # header repeated on each PDF page
            continue
        t = _build(row, m, idx)
        if t:
            txns.append(t)
            last_was_txn = True
            continue
        # Narration wrapped onto the next line (common in PDFs)
        others = [c for f, i in m.items() if f != "narration" for c in [_get(row, m, f)] if c]
        extra = _get(row, m, "narration")
        if last_was_txn and extra and not others and txns:
            prev = txns[-1]
            prev.raw_narration = f"{prev.raw_narration} {extra}".strip()
            info = parse_narration(prev.raw_narration)
            prev.merchant, prev.upi_id = info["merchant"], info["upi_id"]
            prev.ref_no = prev.ref_no or info["ref_no"]
            continue
        skipped += 1
        last_was_txn = False

    order, bal_status = _check_balances(txns)
    if order == "newest_first":
        txns.reverse()
    _assign_hashes(txns, account_id)

    warnings = []
    if not txns:
        warnings.append("No transactions found")
    flagged = sum(1 for t in txns if t.issues)
    if flagged:
        warnings.append(f"{flagged} transactions need review")
    return ImportResult(txns, hdr, m, source, order, bal_status, skipped, warnings)
