"""Remember column mappings per statement layout, so each bank is mapped once."""
import json
import os
from pathlib import Path

DEFAULT_PATH = Path(os.getenv("IMPORTER_PROFILES", "data/profiles.json"))


class ProfileStore:
    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else DEFAULT_PATH
        self._data: dict = {}
        if self.path.exists():
            self._data = json.loads(self.path.read_text())

    def get(self, sig: str) -> dict | None:
        return self._data.get(sig)

    def all(self) -> dict:
        return self._data

    def save(self, sig: str, header: list[str], mapping: dict[str, int], source: str):
        self._data[sig] = {"header": header, "mapping": mapping, "source": source}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self._data, indent=2))

    def delete(self, sig: str) -> bool:
        if self._data.pop(sig, None) is None:
            return False
        self.path.write_text(json.dumps(self._data, indent=2))
        return True
