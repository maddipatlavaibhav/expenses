"""Turn any statement file into a raw grid: list[list[str]]."""
import csv
from pathlib import Path

import pandas as pd


class StatementReadError(Exception):
    pass


class PasswordRequired(StatementReadError):
    pass


def _cell(v) -> str:
    if v is None:
        return ""
    try:
        if pd.isna(v):
            return ""
    except (TypeError, ValueError):
        pass
    if hasattr(v, "strftime"):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, float) and v.is_integer() and abs(v) >= 1e6:
        return str(int(v))          # long ref numbers stored as floats
    return " ".join(str(v).split())  # collapse newlines / double spaces


def _df_to_grid(df: pd.DataFrame) -> list[list[str]]:
    return [[_cell(v) for v in row] for row in df.itertuples(index=False)]


def _read_csv(path: Path) -> list[list[str]]:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    try:
        dialect = csv.Sniffer().sniff(text[:5000], delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    return [[_cell(c) for c in row] for row in csv.reader(text.splitlines(), dialect)]


def _read_excel(path: Path) -> list[list[str]]:
    try:
        return _df_to_grid(pd.read_excel(path, header=None, dtype=object))
    except Exception:
        pass
    # Many banks serve HTML (or plain text) with an .xls extension
    try:
        tables = pd.read_html(path)
        return _df_to_grid(max(tables, key=len))
    except Exception:
        pass
    try:
        return _read_csv(path)
    except Exception as e:
        raise StatementReadError(f"Could not read spreadsheet {path.name}: {e}") from e


def _read_pdf(path: Path, password: str | None) -> list[list[str]]:
    import pdfplumber
    from pdfminer.pdfdocument import PDFPasswordIncorrect

    try:
        rows: list[list[str]] = []
        with pdfplumber.open(path, password=password or "") as pdf:
            for page in pdf.pages:
                tables = page.extract_tables()
                if not tables:   # many bank PDFs have no ruled lines; fall back to text alignment
                    tables = page.extract_tables({"vertical_strategy": "text",
                                                  "horizontal_strategy": "text"})
                for table in tables:
                    rows.extend([_cell(c) for c in r] for r in table)
        return rows
    except Exception as e:
        # pdfplumber wraps pdfminer errors, so check the cause too
        if isinstance(e, PDFPasswordIncorrect) or isinstance(e.__cause__, PDFPasswordIncorrect) \
                or "PDFPasswordIncorrect" in repr(e.args):
            raise PasswordRequired("PDF is password-protected or the password is wrong") from e
        raise StatementReadError(f"Could not read PDF {path.name}: {e}") from e


def read_grid(path: str | Path, password: str | None = None) -> list[list[str]]:
    path = Path(path)
    ext = path.suffix.lower()
    if ext in (".csv", ".txt", ".tsv"):
        return _read_csv(path)
    if ext in (".xls", ".xlsx", ".xlsm"):
        return _read_excel(path)
    if ext == ".pdf":
        return _read_pdf(path, password)
    raise StatementReadError(f"Unsupported file type: {ext}")
